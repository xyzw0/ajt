package com.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BankCRUD extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String action = request.getParameter("action");
       
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/PracStudent", "admin1", "admin1");
             
            if(action.equals("insert")){
                String fname = request.getParameter("fname");
                String accountNumber = request.getParameter("accountNumber");
                String balance = request.getParameter("balance");
                
                PreparedStatement ps = con.prepareStatement("insert into bankInfo(fname, accountNumber, balance) values(?, ?, ?)");
                ps.setString(1, fname);
                ps.setString(2, accountNumber);
                ps.setString(3, balance);
                
                int rows = ps.executeUpdate();
                
                if(rows > 0){
                    out.println("Customer added successfully");
                }
                
                else{
                    out.println("Failed to enter customer");
                }
            }
            
            else if(action.equals("update")){
                int customerId = Integer.parseInt(request.getParameter("customerId"));
                String newBalance = request.getParameter("newBalance");
                
                PreparedStatement ps = con.prepareStatement("update bankInfo SET balance=? WHERE ID=?");
                
                ps.setString(1, newBalance);
                ps.setInt(2, customerId);
                
                int rows = ps.executeUpdate();
                
                if(rows > 0){
                    out.println("Customer Updated successfully");
                }
                
                else{
                    out.println("Failed to update customer");
                }
            }
            
            else if(action.equals("delete")){
                int customerId = Integer.parseInt(request.getParameter("customerId"));
                
                PreparedStatement ps = con.prepareStatement("delete from bankInfo where ID = ?");
                
                ps.setInt(1, customerId);
                int rows = ps.executeUpdate();
                
                if(rows > 0){
                    out.println("Customer Deleted successfully");
                }
                
                else{
                    out.println("Failed to delte customer details");
                }
            }
        }
        
        catch(ClassNotFoundException | SQLException e){
            System.out.println(e);
        }
    }
}
