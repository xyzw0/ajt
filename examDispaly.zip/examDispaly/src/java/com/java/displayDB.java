package com.java;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class displayDB extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        
        try{
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/PracStudent", "admin1", "admin1");
            
            String sql = "SELECT * FROM studentInfo";
            PreparedStatement ps = con.prepareStatement(sql);
            
            ResultSet rs = ps.executeQuery();
            
            out.println("<html><body><h1>Student Information</h1><table border=1 cellspacing=0>");
            out.println("<tr><th>First Name</th><th>Last Name</th><th>Email</th></tr>");
            
            
            while(rs.next()){
                String fname = rs.getString("fname");
                String lname = rs.getString("lname");
                String email = rs.getString("email");
                
                out.println("<tr><td>" + fname + "</td>");
                out.println("<td>" + lname + "</td>");
                out.println("<td>" + email + "</td></tr>");
            }
            
            out.println("</table></body></html>");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
