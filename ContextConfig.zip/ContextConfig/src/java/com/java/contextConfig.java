package com.java;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class contextConfig extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private String configParam;
    private String contextParam;

    @Override
    public void init(ServletConfig config) throws ServletException {
        configParam = config.getInitParameter("configParam");

        ServletContext context = config.getServletContext();
        contextParam = context.getInitParameter("contextParam");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>ServletContext and ServletConfig Demo</title></head><body>");
        out.println("<h3>Servlet Config message: " + configParam + "</h3>");
        out.println("<h3>Servlet Context message: " + contextParam + "</h3>");
        out.println("</body></html>");

        out.close();
    }
}
